from .FBRef import FBRef
from .FiveThirtyEight import FiveThirtyEight
# from . import ScraperFC.ScraperFC
from .Understat import Understat
from .SofaScore import SofaScore
from .ClubElo import ClubElo
from .Capology import Capology
from .Transfermarkt import Transfermarkt
from .shared_functions import *